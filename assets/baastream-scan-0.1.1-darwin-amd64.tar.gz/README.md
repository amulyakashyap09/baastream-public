# BaaStream — The Healthcare Compliance Scanner for Your CI/CD Pipeline

**Shift-left HIPAA, FHIR, and cloud compliance — for DevOps teams at digital health startups.**

Export your config. Run the scan. Get audit-ready evidence in 5 minutes. No agent. No cloud credentials. No PHI.

[![Version](https://img.shields.io/badge/version-0.1.0-blue.svg)](https://github.com/amulyakashyap09/baastream)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Go](https://img.shields.io/badge/go-1.24+-blue.svg)](https://golang.org/)

- 230+ rules across HIPAA, FHIR, HITRUST, SOC 2, GDPR, and 3 cloud providers
- Scans FHIR server configs, CloudTrail exports, Terraform plans, Azure/GCP exports — JSON or YAML
- Evidence-based confidence scoring your auditors can read, not just pass/fail

---

## The Problem

You're a Series A digital health company. You have a FHIR API on AWS HealthLake (or Azure HDS, or GCP). A HIPAA audit is coming in 90 days. Your DevOps engineer has never done a compliance audit before.

Your options today:

| Tool | Problem |
|---|---|
| **Vanta / Drata** ($10K+/yr) | Checks generic AWS/Azure controls. No FHIR rules. No HealthLake or Azure HDS awareness. SOC 2-first, HIPAA bolted on. |
| **Checkov / Trivy** (free) | No healthcare rules. Generic Terraform/K8s security — zero FHIR, zero HealthLake, zero HIPAA context. |
| **Wiz / Orca** ($70K+/yr) | Enterprise CSPM. No FHIR, no healthcare API rules. Pricing excludes startups entirely. |
| **Medcurity** ($499/yr) | Administrative HIPAA — risk assessments, training, documentation. Zero technical scanning, no CI/CD. |
| **Manual audit prep** | 40–80 hours with a $200/hr consultant. No automation, no regression detection. |

**The gap:**

```
                    Administrative          Technical / DevOps
                    (Policy, Training)      (Code, Config, CI/CD)
                    ─────────────────       ────────────────────
Generic:            Vanta, Drata            Checkov, Trivy, OPA
                                            (no healthcare rules)

Healthcare:         Medcurity, Compliancy   ██ EMPTY ██
                    Group, ComplyAssistant   ← BaaStream goes here
```

No tool gives a digital health startup a scanner they can run in CI/CD that says *"your FHIR API is missing OAuth2 scopes, your HealthLake CloudTrail is not WORM-protected, and your audit logs don't have required fields"* — with evidence to show an auditor.

BaaStream is that tool.

---

## Why Now

**2026 is a compliance inflection point for healthcare:**

- **HIPAA Security Rule overhaul** (expected May 2026) — all safeguards become mandatory. Encryption, MFA, vulnerability scanning are no longer "addressable." Orgs must prove technical enforcement, not just document intent. Penalties: up to $2.19M per violation.
- **CMS FHIR mandate** (CMS-0057-F) — payers must report API usage by Jan 2026; all FHIR APIs live by Jan 2027.
- **EU EHDS** — EHR vendors must certify for interoperability by Jan 2026. Fines up to EUR 20M / 4% of turnover.
- **FDA SBOM** — medical device submissions without SBOMs rejected since Oct 2025.

BaaStream validates exactly the technical controls these regulations require — from exported configs, in your pipeline, before production.

---

## Who This Is For

**DevOps and platform engineers** at digital health startups (Series A/B, 10–200 employees) preparing for a HIPAA audit or HITRUST certification — on any cloud.

You are:

- Running a FHIR API on AWS HealthLake, Azure Health Data Services, Google Cloud Healthcare API, HAPI FHIR, or Smile CDR
- Responsible for cloud infrastructure but not a compliance expert
- Looking for something that runs in your pipeline without agents or cloud account credentials
- On one cloud today and possibly expanding to another

---

## Quickstart

### 1. Get your token

```bash
# Sign up at https://baastream.com
# Settings > CLI > Generate Token
export BAASTREAM_CLI_TOKEN=bst_xxxxxxxxxxxxxxxxxxxx
```

### 2. Download the CLI

```bash
1. Go to the [BaaStream Download Asset Page](https://github.com/amulyakashyap09/baastream-public/tree/master/assets).
2. Download the appropriate `.zip` or `.tar.gz` file based on your operating system.
3. Extract the CLI from the downloaded archive.
4. Run the CLI using your token to start scanning.
```

### 3. Run your first scan

```bash
# Scan your FHIR API server config (JSON or YAML)
baastream scan -framework fhir,hipaa -cli-token $BAASTREAM_CLI_TOKEN -input fhir_server_config.json

# Scan your AWS HealthLake CloudTrail export
baastream scan -framework healthlake,hipaa,fhir -cli-token $BAASTREAM_CLI_TOKEN -input cloudtrail-export.json

# Scan your Azure Health Data Services config
baastream scan -framework azure,hipaa,fhir -cli-token $BAASTREAM_CLI_TOKEN -input azure-hds-config.json

# Scan your GCP Healthcare API config
baastream scan -framework google,hipaa,fhir -cli-token $BAASTREAM_CLI_TOKEN -input gcp-healthcare-config.json

# Scan your Terraform plan before applying
terraform plan -out=tfplan && terraform show -json tfplan > tfplan.json
baastream scan -framework terraform,hipaa -cli-token $BAASTREAM_CLI_TOKEN -input tfplan.json
```

---

## What You Scan

BaaStream scans **infrastructure configuration and server settings** — not patient data (PHI).

| Input | How to get it | Framework filter |
|---|---|---|
| FHIR API server config (JSON/YAML) | Export from your FHIR server settings | `-framework fhir,hipaa` |
| AWS CloudTrail export | `aws cloudtrail lookup-events --output json` | `-framework healthlake,hipaa,fhir` |
| Azure HDS diagnostics | `az monitor diagnostic-settings show --output json` | `-framework azure,hipaa,fhir` |
| GCP Healthcare API config | `gcloud healthcare datasets get-iam-policy --format=json` | `-framework google,hipaa,fhir` |
| Terraform plan output | `terraform show -json tfplan` | `-framework terraform,hipaa` |
| FHIR API audit logs | Your server's structured log output | `-framework fhir,audit` |

**What BaaStream does NOT scan:**

- FHIR Patient bundles or clinical data (PHI) — BaaStream scans the infrastructure that protects this data, not the data itself
- Live cloud infrastructure via API — export your config first
- Docker images or binaries

---

## Example: FHIR Server Config

BaaStream accepts your server's configuration as a JSON or YAML file:

```json
{
  "authentication": { "oauth2_enabled": true, "smart_on_fhir_enabled": true },
  "encryption": { "tls_enabled": true, "tls_version": "1.3" },
  "audit_logging": { "enabled": true, "retention_days": 365 },
  "rate_limiting": { "enabled": true, "requests_per_minute": 100 },
  "cors": { "enabled": true, "allowed_origins": ["https://app.example.com"] },
  "fhir_version": "R4",
  "resource_validation": { "enabled": true },
  "bundle_validation": { "enabled": true },
  "metadata": { "endpoint_enabled": true }
}
```

```bash
baastream scan -framework fhir,hipaa -cli-token $BAASTREAM_CLI_TOKEN -input server_config.json
```

---

## Example Output

```
BaaStream Scan Results
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Input:    server_config.json (FHIR Server Config, 95% confidence)
Rules:    19 executed  (15 FHIR + 3 HIPAA + 1 Audit)
Plan:     Pro

CRITICAL  ❌ FHIR-004  FHIR Authentication
          OAuth2 not enabled. SMART on FHIR required for PHI access.
          Fix: Set authentication.oauth2_enabled: true
          Evidence: Field 'authentication.oauth2_enabled' = false

CRITICAL  ❌ HIPAA-BAA-001  Business Associate Agreements
          No BAA tracking configured for PHI vendors.
          Fix: Enable baa_tracking_system with vendor tracking
          Evidence: Field 'baa_tracking_system.baa_signed' not found

HIGH      ❌ HL-001  HealthLake CloudTrail
          CloudTrail not enabled for HealthLake datastore.
          Fix: Enable CloudTrail with multi-region and data events

HIGH      ✅ FHIR-007  FHIR Data Encryption
          TLS 1.3 enabled, data encrypted in transit
          Confidence: 94%

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Score:    61/100  |  PASS: 11  FAIL: 8  |  3 CRITICAL  5 HIGH
```

Every result includes:

- What was found (field name and value)
- Exactly what to fix
- A confidence score (0–100%) so auditors understand the evidence basis

---

## What Happens If I Fail?

A failed scan is not a crisis — it is a finding your auditor can cite, track, and close.

Add `-output json` to any scan command and BaaStream writes a structured evidence file:

```bash
baastream scan \
  -framework hipaa,fhir \
  -output json \
  -cli-token $BAASTREAM_CLI_TOKEN \
  -input server_config.json > compliance-report.json
```

Each failed rule produces a record like this:

```json
{
  "scan_id": "bst-20260411-a1b2c3",
  "timestamp": "2026-04-11T09:14:22Z",
  "input_file": "server_config.json",
  "input_type": "fhir_config",
  "input_confidence": 0.95,
  "summary": {
    "total_rules": 19,
    "passed": 11,
    "failed": 8,
    "score": 61,
    "critical": 3,
    "high": 5
  },
  "results": [
    {
      "rule_id": "FHIR-004",
      "name": "FHIR Authentication",
      "status": "FAIL",
      "severity": "critical",
      "frameworks": ["hipaa", "fhir"],
      "hipaa_section": "§164.312(d) Authentication",
      "evidence": {
        "field": "authentication.oauth2_enabled",
        "found_value": false,
        "expected_value": true,
        "confidence": 0.99
      },
      "remediation": "Enable OAuth2 with SMART on FHIR. Set authentication.oauth2_enabled: true",
      "audit_risk": "Critical — OCR will cite missing OAuth2 as a HIPAA Security Rule violation",
      "breach_cost": "$100,000–$1,900,000 per violation category"
    }
  ]
}
```

**What your auditor gets:**

| Field | What it means for the auditor |
|---|---|
| `scan_id` + `timestamp` | A dated, reproducible evidence artifact they can reference by ID |
| `input_type` + `input_confidence` | Proof BaaStream understood what it scanned — not a guess |
| `evidence.field` + `evidence.found_value` | The exact config field checked, and the value that was found — no ambiguity |
| `hipaa_section` | The specific OCR regulation section the finding maps to, ready to paste into an audit response |
| `remediation` | A one-line fix they can assign, track to closure, and verify on re-scan |

**The audit trail workflow:**

1. Run `baastream scan -output json` in CI/CD on every deploy
2. Save the JSON report as a build artifact (GitHub Actions, Jenkins, S3 — anywhere)
3. When your auditor asks *"how do you know your FHIR API enforces OAuth2 on the date of the assessment?"* — hand them `compliance-report.json`
4. Apply the fix, re-run the scan. The new report shows the same rule now passing, with a new `scan_id` and timestamp. That before/after pair is your remediation evidence

Auditors do not want a dashboard or a login to another tool. They want a file they can open, search, annotate, and attach to a finding. BaaStream gives them exactly that — and it came from your CI/CD pipeline, which means it reflects your actual deployed config, not a checkbox in a GRC tool.

---

## Core Rule Coverage

### FHIR API Compliance (15 rules)

Scans your FHIR server config or audit logs for authentication, encryption, logging, and protocol compliance.

| Rule | What It Checks | Severity |
|---|---|---|
| FHIR-004 | OAuth2 + SMART on FHIR authentication enabled | Critical |
| FHIR-006 | FHIR API audit logging enabled | Critical |
| FHIR-007 | TLS 1.2+ required, HTTP blocked | Critical |
| FHIR-001 | FHIR resource validation enabled | Critical |
| FHIR-005 | Authorization scopes configured (patient/read, user/read) | High |
| FHIR-008 | Rate limiting enabled (prevents PHI scraping) | High |
| FHIR-002 | FHIR R4 or R5 in use (not deprecated DSTU2/R3) | High |
| FHIR-003 | Security headers present (X-Frame-Options, CSP) | High |
| FHIR-011 | OperationOutcome returned on errors (no stack traces) | High |
| FHIR-013 | FHIR bundle transaction validation | High |
| FHIR-009 | CORS restricted to authorized origins | Medium |
| FHIR-010 | Content-Type validation (application/fhir+json only) | Medium |
| FHIR-012 | Search parameter validation enabled | Medium |
| FHIR-014 | CapabilityStatement metadata endpoint exposed | Low |
| FHIR-015 | Conformance statement available | Low |

---

### AWS HealthLake (11 rules)

Scans CloudTrail exports from your HealthLake datastore.

| Rule | What It Checks | Severity |
|---|---|---|
| HL-001 | CloudTrail enabled with multi-region coverage | Critical |
| HL-002 | Data events logged (GetObject, PutObject) for PHI access | Critical |
| HL-009 | Log entries include user identity (not anonymous) | Critical |
| HL-003 | S3 bucket encrypted (SSE-KMS) | High |
| HL-004 | S3 bucket access logging enabled | High |
| HL-005 | KMS key rotation enabled | High |
| HL-007 | API Gateway logs include requestTime, requestId, userIdentity | High |
| HL-010 | No admin/root account used for HealthLake API calls | High |
| HL-011 | HealthLake datastore uses VPC endpoint (not public internet) | High |
| HL-006 | CloudWatch log retention 365+ days | Medium |
| HL-008 | FHIR resource paths follow `/Patient/{id}` patterns | Medium |

```bash
aws cloudtrail lookup-events \
  --lookup-attributes AttributeKey=EventSource,AttributeValue=healthlake.amazonaws.com \
  --output json > cloudtrail.json

baastream scan -framework healthlake,hipaa,fhir -cli-token $BAASTREAM_CLI_TOKEN -input cloudtrail.json
```

---

### Azure Health Data Services (12 rules)

Scans Activity Log, diagnostic settings, Key Vault, and private endpoint configuration.

| Rule | What It Checks | Severity |
|---|---|---|
| AZ-HDS-001 | Activity Log enabled with multi-region coverage | Critical |
| AZ-HDS-002 | Diagnostic settings include Administrative and Security categories | High |
| AZ-HDS-003 | Storage account encrypted (SSE or CMK) | High |
| AZ-HDS-004 | Storage: HTTPS-only, no public blob access, network ACL deny | High |
| AZ-HDS-005 | Key Vault automatic key rotation enabled (90-day policy) | Medium |
| AZ-HDS-006 | Log Analytics workspace retention 365+ days | High |
| AZ-HDS-009 | Log entries include Service Principal / Managed Identity / AAD user | High |
| AZ-HDS-011 | Managed Identity used for service calls (no admin/anonymous) | High |
| AZ-HDS-012 | Private endpoint configured (no public internet) | High |

```bash
az monitor diagnostic-settings show \
  --resource /subscriptions/{sub-id}/resourceGroups/rg-health/providers/Microsoft.HealthcareApis/workspaces/{ws}/fhirservices/{svc} \
  --output json > azure-hds-config.json

baastream scan -framework azure,hipaa,fhir -cli-token $BAASTREAM_CLI_TOKEN -input azure-hds-config.json
```

---

### Google Cloud Healthcare API (13 rules)

Scans Cloud Audit Logs, KMS, VPC Service Controls, and IAM configuration.

| Rule | What It Checks | Severity |
|---|---|---|
| GCH-001 | Cloud Audit Logs enabled with multi-region coverage | Critical |
| GCH-002 | DATA_READ and DATA_WRITE events logged for FHIR stores | High |
| GCH-003 | Cloud Storage encrypted (CMEK preferred) | High |
| GCH-004 | Cloud Storage: access logging, restrictive IAM (no allUsers) | High |
| GCH-009 | Log entries include principalEmail or Service Account identity | High |
| GCH-011 | Service Account used for API calls (no admin/anonymous) | High |
| GCH-012 | VPC Service Controls enforced (not DRY_RUN) | High |
| GCH-013 | Healthcare API IAM uses least-privilege roles (not Owner/Editor) | High |

```bash
gcloud healthcare datasets get-iam-policy my-dataset \
  --location=us-central1 --format=json > gcp-healthcare-config.json

baastream scan -framework google,hipaa,fhir -cli-token $BAASTREAM_CLI_TOKEN -input gcp-healthcare-config.json
```

---

## CI/CD Integration

### GitHub Actions

```yaml
name: Healthcare Compliance Scan

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  compliance:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Download BaaStream CLI
        run: |
          curl -L https://baastream.com/install/linux-amd64 -o baastream
          chmod +x baastream

      - name: Scan FHIR API Config
        env:
          BAASTREAM_CLI_TOKEN: ${{ secrets.BAASTREAM_CLI_TOKEN }}
        run: |
          baastream scan \
            -framework hipaa,fhir \
            -output json \
            -cli-token $BAASTREAM_CLI_TOKEN \
            -input config/production.json > compliance-report.json

      - name: Upload Compliance Report
        uses: actions/upload-artifact@v4
        with:
          name: compliance-report
          path: compliance-report.json
```

### Jenkins

```groovy
pipeline {
    agent any
    environment {
        BAASTREAM_CLI_TOKEN = credentials('baastream-cli-token')
    }
    stages {
        stage('Compliance Scan') {
            steps {
                sh '''
                    curl -L https://baastream.com/install/linux-amd64 -o baastream
                    chmod +x baastream
                    baastream scan \
                        -framework hipaa,fhir,healthlake \
                        -output json \
                        -cli-token $BAASTREAM_CLI_TOKEN \
                        -input config/production.json > compliance-report.json
                '''
                archiveArtifacts artifacts: 'compliance-report.json'
            }
        }
    }
}
```

---

## Full Compliance Coverage (230+ Rules)

The FHIR + multi-cloud rules above are the core differentiator. Additional frameworks are available in higher tiers for teams pursuing formal certifications.

| Framework | Rules | Tier | When you need it |
|---|---|---|---|
| **FHIR R4/R5** | 15 | Free | Always — core FHIR API compliance |
| **Audit Logging** | 7 | Pro | HIPAA audit prep |
| **Encryption** | 6 | Starter | HIPAA audit prep |
| **Authentication & Access Control** | 8 | Starter | HIPAA audit prep |
| **SOC 2 Type II** | 10 | Starter | SOC 2 audit prep |
| **GDPR** | 8 | Starter | EU patient data |
| **Log Access Control** | 12 | Starter | HITRUST Level 2 |
| **Log Integrity** (WORM, hashes, chain of custody) | 12 | Pro | HITRUST Level 1 |
| **HIPAA Security Rule** | 3 dedicated + mapped | Enterprise | Before your first audit |
| **AWS HealthLake** | 11 | Enterprise | On AWS with HealthLake |
| **Azure Health Data Services** | 12 | Enterprise | On Azure with HDS |
| **Google Cloud Healthcare API** | 13 | Enterprise | On GCP with Healthcare API |
| **HITRUST CSF** | 10 | Enterprise | Formal HITRUST certification |
| **State Privacy** (TX TDPSA, CA CCPA/CPRA, WA MHMDA) | 10 | Enterprise | US state operations |
| **ISO 27001** | 15 | Enterprise | Enterprise security reviews |
| **SBOM** (CycloneDX/SPDX, FDA guidance) | 6 | Enterprise | FDA SaMD submissions |
| **Zero Trust** | 4 | Enterprise | Zero Trust architecture |

---

## HIPAA Security Rule Mapping

BaaStream maps rules to HIPAA Security Rule implementation specifications — the sections OCR auditors actually check.

| HIPAA Section | BaaStream Rules | What It Covers |
|---|---|---|
| §164.312(a)(1) Access Control | AUTH-001, AUTH-008, HIPAA-MIN-001 | Unique user IDs, emergency access, automatic logoff, MFA |
| §164.312(b) Audit Controls | AUDIT-001 through AUDIT-PRO-007 | Activity logs, retention, tamper protection |
| §164.312(c)(1) Integrity | LI-001 through LI-012 | WORM storage, hash verification, chain of custody |
| §164.312(d) Authentication | AUTH-001, AUTH-005, AUTH-007, FHIR-004 | OAuth2, SMART on FHIR, SSO, session management |
| §164.312(e)(1) Transmission Security | ENC-PRO-001, ENC-PRO-006, FHIR-007 | TLS 1.2+, certificate management, HTTPS-only |
| §164.308 Administrative | HIPAA-BREACH-001, HIPAA-BAA-001 | Breach notification, BAA tracking |

---

## Pricing

| Tier | Price | Rules | Target |
|---|---|---|---|
| **Free** | $0 | 10 | Individual devs, evaluation, pre-seed startups |
| **Starter** | $299/mo | 30 | Series A startups, HIPAA + SOC 2 + GDPR basics |
| **Pro** | $799/mo | 75 | Growing teams pursuing HITRUST / SOC 2 / GDPR |
| **Enterprise** | $2,499/mo | 150+ | Health systems, EHR vendors, FDA SaMD companies |

**Free** — Core FHIR rules. Text summary output only. Personal/evaluation use.

**Starter** — Everything in Free + encryption, auth, SOC 2, GDPR, log access rules. JSON and PDF output, GitHub Actions + Jenkins plugins.

**Pro** — Everything in Starter + audit logging, log integrity (WORM/hashes), advanced analytics, priority remediation, audit-ready exports.

**Enterprise** — Everything in Pro + all 36 multi-cloud healthcare rules (HealthLake, Azure HDS, GCP), HIPAA dedicated rules, HITRUST, ISO 27001, state privacy, SBOM (FDA SaMD), Zero Trust, custom rules, on-prem deployment, dedicated compliance support.

---

## How It Works

```
Input file (FHIR server config / CloudTrail JSON / Terraform plan / YAML / logs)
    │
    ▼
Detector — classifies input type with confidence score
    │  fhir_config | aws_cloudtrail | azure_template |
    │  gcp_template | log_file | sbom_document | terraform_plan
    ▼
Rule Selector — filters by plan tier, tags, severity, input type
    ▼
Rule Engine (Go) — evaluates each rule condition
    │  Structured field checks (config) + regex fallback (logs)
    │  AND/OR compound conditions
    │  Evidence collection: field name, found value, confidence
    ▼
Evidence Aggregator — per-rule confidence score (0–100%)
    ▼
Output — JSON / CSV / terminal summary / PDF (Pro+)
```

Rules are YAML — readable and auditable:

```yaml
- id: "FHIR-004"
  name: "FHIR Authentication"
  severity: "critical"
  tier: ["community"]
  tags: ["fhir", "hipaa", "authentication"]
  condition:
    or:
      - field: "authentication.oauth2_enabled"
        operator: "equals"
        value: true
      - field: "smart_on_fhir_enabled"
        operator: "equals"
        value: true
      - field: "log_lines"
        operator: "regex"
        value: "(?i)(oauth2.*enabled|smart.*on.*fhir)"
  remediation: "Enable OAuth2 with SMART on FHIR. Set authentication.oauth2_enabled: true"
  business_impact:
    audit_risk: "Critical — OCR will cite missing OAuth2 as a HIPAA Security Rule violation"
    breach_cost: "$100,000–$1,900,000 per violation category"
```

---

## FAQ

**Q: What is the difference between BaaStream and Vanta/Drata?**

Vanta and Drata are GRC platforms — they check generic cloud controls (is MFA on? is S3 public?) and collect compliance evidence via integrations. They cost $10K–$12K/yr, are SOC 2-first, and bolt on HIPAA. BaaStream scans your actual config files for healthcare-specific violations — it understands HealthLake, SMART on FHIR, FHIR R4/R5, and OCR-grade logging. BaaStream is complementary: it validates the technical controls, Vanta/Drata track the policy side.

**Q: What is the difference between BaaStream and Checkov/Trivy?**

Checkov and Trivy are generic IaC scanners with CIS benchmarks and basic HIPAA crosswalks. They have zero FHIR rules, zero HealthLake rules, and cannot validate FHIR server configs or CloudTrail exports. BaaStream has 230+ healthcare-specific rules that Checkov/Trivy will never build because healthcare compliance requires domain expertise, not just generic security checks.

**Q: Does BaaStream connect to my AWS / Azure / GCP account?**

No. BaaStream is a static scanner — you export the config or CloudTrail JSON yourself and pass it to the CLI. BaaStream never calls cloud provider APIs directly. This means zero IAM roles, zero security risk, zero procurement friction.

**Q: Why won't BaaStream scan my FHIR Patient bundles?**

FHIR Patient bundles are clinical data (PHI). BaaStream scans the infrastructure that *protects* that data — server configs, encryption settings, access controls, audit logging — not the data itself. This is by design: scanning PHI would make BaaStream a HIPAA Business Associate, requiring BAAs, compliance programs, and creating liability. By not touching PHI, BaaStream can be adopted in 5 minutes without legal review.

**Q: Can I run this offline or air-gapped?**

The Free tier requires internet access to verify your token. Contact us for enterprise on-prem deployment.

**Q: Does this guarantee HIPAA compliance?**

No. BaaStream identifies technical misconfigurations and produces evidence for auditors. Full HIPAA compliance requires legal, operational, and organizational measures beyond what any tool can validate. BaaStream covers the technical controls in §164.312 — your compliance officer handles the rest.

**Q: Does BaaStream support YAML input files?**

Yes. BaaStream accepts both JSON and YAML input files. It auto-detects the format by file extension (`.json`, `.yaml`, `.yml`).

---

## License

MIT — see [LICENSE](LICENSE)

---

*BaaStream v0.1.0 — March 2026*
